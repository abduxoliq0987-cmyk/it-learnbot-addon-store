@echo off
chcp 65001 >nul
title IT Learn Browser - O'rnatish
cd /d "%~dp0"
echo ==========================================
echo        IT Learn Browser o'rnatish
echo ==========================================
py -3.13 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.13 topilmadi. Python 3.13 ni o'rnating.
  pause
  exit /b 1
)
py -3.13 -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
  echo Kutubxonalarni o'rnatishda xatolik yuz berdi.
  pause
  exit /b 1
)
echo.
echo Tayyor! Endi run.bat faylini ishga tushiring.
pause
