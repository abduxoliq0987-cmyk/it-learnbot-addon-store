# IT Learn Browser

Windows 11 uchun mustaqil, macOS uslubidagi ish stoli brauzeri. Python 3.13, PySide6 va Qt WebEngine (Chromium) asosida ishlaydi.

## Imkoniyatlar
- Google qidiruvi (standart)
- Haqiqiy veb-sahifalarni Chromium WebEngine orqali ochish
- Bir nechta tab, tablarni yopish va ko'chirish
- Orqaga, oldinga, yangilash va bosh sahifa
- Xatcho'plar va ko'rilgan sahifalar tarixi (joriy ishga tushirish davomida)
- Fayllarni Windows `Downloads` papkasiga yuklash
- Google, Bing yoki DuckDuckGo qidiruvini tanlash
- Qorong'i/yorug' mavzu
- Klaviatura yorliqlari

## O'rnatish
1. Python 3.13 (64-bit) o'rnatilgan bo'lsin.
2. ZIP faylni papkaga chiqaring.
3. `install.bat` faylini ikki marta bosing va tugashini kuting.
4. `run.bat` faylini ishga tushiring.

Yoki PowerShell'da:
```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

## Yorliqlar
- `Ctrl+T` — yangi tab
- `Ctrl+W` — joriy tabni yopish
- `Ctrl+L` — manzil satriga o'tish
- `Ctrl+R` — sahifani yangilash
- `Alt+Left` — orqaga
- `Alt+Right` — oldinga
- `Ctrl+D` — xatcho'pga qo'shish
- `Ctrl+H` — tarix
- Menyu → `3D Adventure o‘yini` — 3D sarguzashtni ochish

## Ma'lumotlar
Xatcho'plar `%USERPROFILE%\\AppData\\Local\\ITLearnBrowser\\bookmarks.json` faylida saqlanadi.
Tarix hozircha dastur ishlayotgan vaqt davomida saqlanadi.

## Eslatma
Bu Chromium asosidagi mustaqil brauzer ilovasi, lekin o'zining alohida brauzer dvigatelini yozmaydi. Ba'zi saytlar o'z xavfsizlik siyosati yoki DRM sababli ayrim funksiyalarni cheklashi mumkin. Ilova internetga ulanishni talab qiladi.
