import sys
import os
import json
from pathlib import Path
from urllib.parse import quote_plus

from PySide6.QtCore import QUrl, Qt, QSize
from PySide6.QtGui import QAction, QKeySequence, QIcon, QColor
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QToolButton, QMenu, QMessageBox, QDialog,
    QFormLayout, QCheckBox, QComboBox, QLabel, QDialogButtonBox, QStyle
)
from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEngineDownloadRequest
from PySide6.QtWebEngineWidgets import QWebEngineView


APP_NAME = "IT Learn Browser"
HOME_URL = "https://www.google.com"
APP_DIR = Path.home() / "AppData" / "Local" / "ITLearnBrowser"
APP_DIR.mkdir(parents=True, exist_ok=True)
BOOKMARKS_FILE = APP_DIR / "bookmarks.json"


def app_icon(app, standard_icon):
    return app.style().standardIcon(standard_icon)


class BrowserTab(QWidget):
    def __init__(self, browser, url=HOME_URL):
        super().__init__()
        self.browser = browser
        self.view = QWebEngineView(self)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.view)
        self.view.urlChanged.connect(self.on_url_changed)
        self.view.titleChanged.connect(self.on_title_changed)
        self.view.loadFinished.connect(self.on_load_finished)
        self.view.setUrl(QUrl(url))

    def on_url_changed(self, url):
        if self.browser.current_tab() is self:
            self.browser.url_bar.setText(url.toString())

    def on_title_changed(self, title):
        index = self.browser.tabs.indexOf(self)
        if index >= 0:
            self.browser.tabs.setTabText(index, (title or "Yangi sahifa")[:22])

    def on_load_finished(self, ok):
        if ok:
            url = self.view.url().toString()
            if url and url not in ("about:blank",):
                self.browser.add_history(url, self.view.title())


class SettingsDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Sozlamalar")
        self.setMinimumWidth(380)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.search = QComboBox()
        self.search.addItem("Google", "https://www.google.com/search?q={}")
        self.search.addItem("Bing", "https://www.bing.com/search?q={}")
        self.search.addItem("DuckDuckGo", "https://duckduckgo.com/?q={}")
        current = parent.search_template
        idx = self.search.findData(current)
        if idx >= 0:
            self.search.setCurrentIndex(idx)
        self.home = QLineEdit(parent.home_url)
        self.dark = QCheckBox("Qorong‘i mavzu")
        self.dark.setChecked(parent.dark_mode)
        form.addRow("Qidiruv tizimi:", self.search)
        form.addRow("Bosh sahifa:", self.home)
        form.addRow("", self.dark)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class BrowserWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1280, 820)
        self.setMinimumSize(850, 560)
        self.home_url = HOME_URL
        self.search_template = "https://www.google.com/search?q={}"
        self.dark_mode = True
        self.history = []
        self.bookmarks = self.load_bookmarks()
        self._build_ui()
        self._build_menus()
        self.apply_theme()
        self.add_tab()

    def _build_ui(self):
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 8, 10, 8)
        root.setSpacing(8)

        # macOS-inspired traffic-light controls and tab strip
        top = QHBoxLayout()
        top.setSpacing(6)
        for color in ("#ff5f57", "#febc2e", "#28c840"):
            dot = QLabel()
            dot.setFixedSize(12, 12)
            dot.setStyleSheet(f"background:{color};border-radius:6px;")
            top.addWidget(dot)
        top.addSpacing(8)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.on_tab_changed)
        self.tabs.setElideMode(Qt.ElideRight)
        top.addWidget(self.tabs, 1)

        self.new_tab_button = QToolButton()
        self.new_tab_button.setText("+")
        self.new_tab_button.setToolTip("Yangi tab (Ctrl+T)")
        self.new_tab_button.clicked.connect(self.add_tab)
        top.addWidget(self.new_tab_button)
        root.addLayout(top)

        nav = QHBoxLayout()
        nav.setSpacing(6)
        self.back_btn = self.make_tool_button("‹", "Orqaga", lambda: self.current_view() and self.current_view().back())
        self.forward_btn = self.make_tool_button("›", "Oldinga", lambda: self.current_view() and self.current_view().forward())
        self.reload_btn = self.make_tool_button("↻", "Yangilash", lambda: self.current_view() and self.current_view().reload())
        self.home_btn = self.make_tool_button("⌂", "Bosh sahifa", lambda: self.navigate(self.home_url))
        nav.addWidget(self.back_btn)
        nav.addWidget(self.forward_btn)
        nav.addWidget(self.reload_btn)
        nav.addWidget(self.home_btn)

        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("Google orqali qidiring yoki sayt manzilini kiriting")
        self.url_bar.setClearButtonEnabled(True)
        self.url_bar.returnPressed.connect(self.navigate_from_bar)
        nav.addWidget(self.url_bar, 1)

        self.bookmark_btn = self.make_tool_button("☆", "Xatcho‘pga qo‘shish", self.add_bookmark)
        nav.addWidget(self.bookmark_btn)
        self.menu_btn = self.make_tool_button("⋯", "Menyu", self.show_app_menu)
        nav.addWidget(self.menu_btn)
        root.addLayout(nav)

        self.status = QLabel("Tayyor")
        self.status.setObjectName("status")
        root.addWidget(self.status)
        self.setCentralWidget(central)

        self.tabs.currentChanged.connect(lambda _: self.update_navigation())
        self._create_shortcuts()

    def make_tool_button(self, text, tooltip, callback):
        b = QToolButton()
        b.setText(text)
        b.setToolTip(tooltip)
        b.setFixedSize(34, 32)
        b.clicked.connect(callback)
        return b

    def _build_menus(self):
        self.app_menu = QMenu(self)
        self.app_menu.addAction("Yangi tab", self.add_tab, QKeySequence.New)
        self.app_menu.addAction("Yangi oyna", self.new_window)
        self.app_menu.addSeparator()
        self.app_menu.addAction("3D Adventure o‘yini", self.open_adventure_game)
        self.app_menu.addSeparator()
        self.app_menu.addAction("Xatcho‘plar", self.show_bookmarks)
        self.app_menu.addAction("Tarix", self.show_history)
        self.app_menu.addAction("Yuklamalar papkasi", self.open_downloads)
        self.app_menu.addSeparator()
        self.app_menu.addAction("Sozlamalar", self.open_settings)
        self.app_menu.addAction("IT Learn Browser haqida", self.about)

    def _create_shortcuts(self):
        shortcuts = [
            ("Ctrl+T", self.add_tab), ("Ctrl+W", lambda: self.close_tab(self.tabs.currentIndex())),
            ("Ctrl+L", self.focus_url), ("Alt+Left", lambda: self.current_view() and self.current_view().back()),
            ("Alt+Right", lambda: self.current_view() and self.current_view().forward()),
            ("Ctrl+R", lambda: self.current_view() and self.current_view().reload()),
            ("Ctrl+D", self.add_bookmark), ("Ctrl+H", self.show_history),
        ]
        for key, fn in shortcuts:
            action = QAction(self)
            action.setShortcut(QKeySequence(key))
            action.triggered.connect(fn)
            self.addAction(action)

    def add_tab(self, url=HOME_URL):
        tab = BrowserTab(self, url)
        index = self.tabs.addTab(tab, "Yangi tab")
        self.tabs.setCurrentIndex(index)
        tab.view.loadProgress.connect(lambda p: self.status.setText(f"Yuklanmoqda… {p}%"))
        tab.view.loadFinished.connect(lambda ok: self.status.setText("Tayyor" if ok else "Sahifa yuklanmadi"))
        self.update_navigation()
        return tab

    def current_tab(self):
        w = self.tabs.currentWidget()
        return w if isinstance(w, BrowserTab) else None

    def current_view(self):
        tab = self.current_tab()
        return tab.view if tab else None

    def close_tab(self, index):
        if self.tabs.count() <= 1:
            self.current_view().setUrl(QUrl(self.home_url))
            return
        widget = self.tabs.widget(index)
        self.tabs.removeTab(index)
        widget.deleteLater()

    def on_tab_changed(self, _):
        self.update_navigation()

    def update_navigation(self):
        view = self.current_view()
        if not view:
            return
        self.url_bar.setText(view.url().toString())
        self.back_btn.setEnabled(view.history().canGoBack())
        self.forward_btn.setEnabled(view.history().canGoForward())

    def navigate_from_bar(self):
        raw = self.url_bar.text().strip()
        if not raw:
            return
        if "://" in raw or raw.startswith("file:"):
            target = raw
        elif " " not in raw and ("." in raw or raw.startswith("localhost")):
            target = "https://" + raw
        else:
            target = self.search_template.format(quote_plus(raw))
        self.navigate(target)

    def navigate(self, url):
        view = self.current_view()
        if view:
            view.setUrl(QUrl(url))
            self.url_bar.setText(url)

    def focus_url(self):
        self.url_bar.setFocus()
        self.url_bar.selectAll()

    def add_history(self, url, title):
        item = {"url": url, "title": title or url}
        if not self.history or self.history[-1]["url"] != url:
            self.history.append(item)
            self.history = self.history[-500:]

    def add_bookmark(self):
        view = self.current_view()
        if not view:
            return
        item = {"title": view.title() or view.url().host(), "url": view.url().toString()}
        if item["url"] and not any(x["url"] == item["url"] for x in self.bookmarks):
            self.bookmarks.append(item)
            self.save_bookmarks()
            self.bookmark_btn.setText("★")
            self.status.setText("Xatcho‘p saqlandi")

    def load_bookmarks(self):
        try:
            return json.loads(BOOKMARKS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return []

    def save_bookmarks(self):
        BOOKMARKS_FILE.write_text(json.dumps(self.bookmarks, ensure_ascii=False, indent=2), encoding="utf-8")

    def show_bookmarks(self):
        menu = QMenu(self)
        if not self.bookmarks:
            menu.addAction("Hozircha xatcho‘p yo‘q").setEnabled(False)
        for item in self.bookmarks:
            menu.addAction(item["title"][:45], lambda checked=False, u=item["url"]: self.navigate(u))
        menu.addSeparator()
        menu.addAction("Joriy sahifani saqlash", self.add_bookmark)
        menu.exec(self.menu_btn.mapToGlobal(self.menu_btn.rect().bottomLeft()))

    def show_history(self):
        menu = QMenu(self)
        if not self.history:
            menu.addAction("Tarix hozircha bo‘sh").setEnabled(False)
        for item in reversed(self.history[-40:]):
            menu.addAction(item["title"][:45], lambda checked=False, u=item["url"]: self.navigate(u))
        menu.exec(self.menu_btn.mapToGlobal(self.menu_btn.rect().bottomLeft()))

    def show_app_menu(self):
        self.app_menu.exec(self.menu_btn.mapToGlobal(self.menu_btn.rect().bottomLeft()))

    def open_settings(self):
        dialog = SettingsDialog(self)
        if dialog.exec() == QDialog.Accepted:
            self.search_template = dialog.search.currentData()
            self.home_url = dialog.home.text().strip() or HOME_URL
            self.dark_mode = dialog.dark.isChecked()
            self.apply_theme()

    def apply_theme(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QMainWindow, QWidget { background:#202124; color:#e8eaed; font-family:'Segoe UI'; font-size:10pt; }
                QTabWidget::pane { border:1px solid #3c4043; border-radius:10px; background:#fff; }
                QTabBar::tab { background:#303134; color:#bdc1c6; padding:8px 14px; margin-right:4px; border-radius:9px; }
                QTabBar::tab:selected { background:#45474a; color:white; }
                QLineEdit { background:#303134; color:#f1f3f4; border:1px solid #4a4d50; border-radius:16px; padding:8px 14px; selection-background-color:#8ab4f8; }
                QToolButton, QPushButton { background:#303134; color:#e8eaed; border:0; border-radius:9px; padding:5px; }
                QToolButton:hover, QPushButton:hover { background:#45474a; }
                QToolButton:disabled { color:#666; }
                QLabel#status { color:#9aa0a6; font-size:9pt; padding-left:5px; }
                QMenu { background:#303134; color:#eee; border:1px solid #555; }
                QMenu::item:selected { background:#4b4e52; }
                QComboBox { background:#303134; padding:6px; border-radius:6px; }
            """)
        else:
            self.setStyleSheet("""
                QMainWindow, QWidget { background:#f5f6f8; color:#202124; font-family:'Segoe UI'; font-size:10pt; }
                QTabWidget::pane { border:1px solid #d8dce2; border-radius:10px; background:white; }
                QTabBar::tab { background:#e8eaed; color:#444; padding:8px 14px; margin-right:4px; border-radius:9px; }
                QTabBar::tab:selected { background:white; color:#111; }
                QLineEdit { background:white; color:#202124; border:1px solid #d4d8de; border-radius:16px; padding:8px 14px; }
                QToolButton, QPushButton { background:#e8eaed; color:#202124; border:0; border-radius:9px; padding:5px; }
                QToolButton:hover, QPushButton:hover { background:#d9dde3; }
                QLabel#status { color:#666; font-size:9pt; padding-left:5px; }
            """)

    def open_adventure_game(self):
        game_file = Path(__file__).resolve().parent / "game" / "index.html"
        if not game_file.exists():
            QMessageBox.warning(self, "3D Adventure", "O‘yin fayli topilmadi.")
            return
        self.add_tab(QUrl.fromLocalFile(str(game_file)).toString())

    def open_downloads(self):
        path = Path.home() / "Downloads"
        os.startfile(str(path))

    def new_window(self):
        self.other_window = BrowserWindow()
        self.other_window.show()

    def about(self):
        QMessageBox.about(self, APP_NAME, "IT Learn Browser\n\nPython 3.13 + PySide6 + Chromium WebEngine\nGoogle qidiruvi va haqiqiy veb-sahifalar uchun mustaqil brauzer.")

    def closeEvent(self, event):
        event.accept()


def configure_downloads(profile):
    def on_download(download: QWebEngineDownloadRequest):
        downloads = Path.home() / "Downloads"
        downloads.mkdir(exist_ok=True)
        name = download.downloadFileName() or "download"
        download.setDownloadDirectory(str(downloads))
        download.setDownloadFileName(name)
        download.accept()
    profile.downloadRequested.connect(on_download)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("IT Learn")
    app.setStyle("Fusion")
    profile = QWebEngineProfile.defaultProfile()
    configure_downloads(profile)
    window = BrowserWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
